using Microsoft.AspNetCore.Mvc;


namespace neWeb.Controllers
{
    public class CursosController : Controller
    {
        public IActionResult Alg2()
        {
            return View();
        }

        public IActionResult Calculo1()
        {
            return View();
        }


        public IActionResult DiseñoWeb()
        {
            return View();
        }
        public IActionResult SistemasdeInformacion()
        {
            return View();
        }
        public IActionResult Sw1()
        {
            return View();
        }
    }
}